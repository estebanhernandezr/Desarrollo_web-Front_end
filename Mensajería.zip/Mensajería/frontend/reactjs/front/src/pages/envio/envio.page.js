import React, { useState } from "react";

import Menu from '../../components/menu/menu.component'

import './envio.page.css';

import axios from "axios";

class Send extends React.Component {
    constructor(props) {
        super(props);
    };

    render() {
        return (
            <>
                <Menu/>
                <h1>PAGINA DE ENVIO MASIVO</h1>
                <div style={{ textAlign: "center" }}>
                    <h1>REACTJS CSV IMPORT EXAMPLE </h1>
                    <form>
                        <input type={"file"} accept={".csv"} />
                        <button>IMPORT CSV</button>
                    </form>
                </div>
            </>
        );
    };
}

export default Send;
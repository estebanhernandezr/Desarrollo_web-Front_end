import React from "react";

import Menu from '../../components/menu/menu.component'

import './actualizacion.page.css';

import axios from "axios";

class Update extends React.Component {
    constructor(props) {
        super(props);
    };

    render() {
        return (
            <>
                <Menu/>
                <h1>PAGINA DE ACTUALIZACION</h1>
            </>
        );
    };
}

export default Update;
import React from "react";

import Menu from '../../components/menu/menu.component'

import './registro.page.css';

import axios from "axios";

class Register extends React.Component {
    constructor(props) {
        super(props);
    };

    render() {
        return (
            <>
                <Menu/>
                <h1>PAGINA DE REGISTRO</h1>
            </>
        );
    };
}

export default Register;